//Page elements to perform actions

export const ELEMENTS = {
    link: 'https://staging.bazardoconsorcio.com.br/select/login',
    otherAdmins: '.grid > :nth-child(1)',
    itauAdmin: '.grid > :nth-child(2)',
    inputUser: 'body > main > .devise-form > fieldset > #customer_email',
    inputPass: 'main > .devise-form > fieldset > .password-group > #customer_password',
    entrarButton: 'body > main > .devise-form > .buttons > input'
}

export const VALUE = {
    user1: 'danielli+1@bazardoconsorcio.com.br',
    user3: 'danielli+3@bazardoconsorcio.com.br',
    user4: 'danielli+4@bazardoconsorcio.com.br',
    password:'V@nderlarkin14',
}
